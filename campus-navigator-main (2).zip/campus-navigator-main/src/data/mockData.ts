import { BookOpen, Brain, Users, LayoutDashboard, Award, User } from "lucide-react";

export interface Skill {
  id: string;
  name: string;
  category: "technical" | "non-technical";
  level: "beginner" | "intermediate" | "advanced";
  progress: number;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  skills: string[];
  status: "in-progress" | "completed";
  date: string;
}

export interface Certification {
  id: string;
  name: string;
  issuer: string;
  date: string;
  link: string;
}

export interface CollabPost {
  id: string;
  author: string;
  avatar: string;
  title: string;
  description: string;
  tags: string[];
  date: string;
  responses: number;
}

export interface DaySchedule {
  time: string;
  subject: string;
  type: "class" | "lab" | "free";
}

export const studentProfile = {
  name: "Dhanush Kumar",
  department: "Electronics & Communication",
  semester: 4,
  rollNumber: "ECE21045",
  email: "dhanush.k@campus.edu",
  avatar: "DK",
  bio: "IoT enthusiast & full-stack developer. Passionate about embedded systems and web technologies.",
  joinedDate: "Aug 2023",
};

export const attendanceData = [
  { subject: "Digital Signal Processing", attended: 38, total: 45, percentage: 84 },
  { subject: "Microprocessors", attended: 32, total: 44, percentage: 73 },
  { subject: "Signals & Systems", attended: 40, total: 45, percentage: 89 },
  { subject: "Electromagnetic Theory", attended: 28, total: 43, percentage: 65 },
  { subject: "Data Structures", attended: 41, total: 44, percentage: 93 },
];

export const weeklyStudyHours = [
  { day: "Mon", hours: 4.5 },
  { day: "Tue", hours: 3.2 },
  { day: "Wed", hours: 5.1 },
  { day: "Thu", hours: 2.8 },
  { day: "Fri", hours: 4.0 },
  { day: "Sat", hours: 6.5 },
  { day: "Sun", hours: 3.0 },
];

export const monthlyProgress = [
  { month: "Sep", gpa: 7.8, skills: 2 },
  { month: "Oct", gpa: 8.1, skills: 3 },
  { month: "Nov", gpa: 7.9, skills: 4 },
  { month: "Dec", gpa: 8.4, skills: 5 },
  { month: "Jan", gpa: 8.6, skills: 7 },
  { month: "Feb", gpa: 8.8, skills: 8 },
];

export const skills: Skill[] = [
  { id: "1", name: "Python", category: "technical", level: "advanced", progress: 85 },
  { id: "2", name: "React.js", category: "technical", level: "intermediate", progress: 65 },
  { id: "3", name: "Arduino / IoT", category: "technical", level: "advanced", progress: 90 },
  { id: "4", name: "C / C++", category: "technical", level: "intermediate", progress: 70 },
  { id: "5", name: "SQL & Databases", category: "technical", level: "beginner", progress: 40 },
  { id: "6", name: "Public Speaking", category: "non-technical", level: "intermediate", progress: 60 },
  { id: "7", name: "Technical Writing", category: "non-technical", level: "beginner", progress: 35 },
  { id: "8", name: "Team Leadership", category: "non-technical", level: "intermediate", progress: 55 },
];

export const projects: Project[] = [
  {
    id: "1",
    title: "Smart Home Automation System",
    description: "IoT-based home automation using ESP32 and MQTT protocol with a React dashboard.",
    skills: ["Arduino / IoT", "React.js", "Python"],
    status: "completed",
    date: "Dec 2025",
  },
  {
    id: "2",
    title: "Campus Navigation App",
    description: "Indoor navigation system using BLE beacons for college campus.",
    skills: ["React.js", "Python", "SQL & Databases"],
    status: "in-progress",
    date: "Feb 2026",
  },
  {
    id: "3",
    title: "Signal Processing Toolkit",
    description: "MATLAB-to-Python conversion toolkit for DSP lab experiments.",
    skills: ["Python", "C / C++"],
    status: "completed",
    date: "Oct 2025",
  },
];

export const certifications: Certification[] = [
  { id: "1", name: "AWS Cloud Practitioner", issuer: "Amazon Web Services", date: "Jan 2026", link: "#" },
  { id: "2", name: "Python for Data Science", issuer: "Coursera", date: "Nov 2025", link: "#" },
  { id: "3", name: "IoT Fundamentals", issuer: "Cisco Networking Academy", date: "Sep 2025", link: "#" },
];

export const collabPosts: CollabPost[] = [
  {
    id: "1",
    author: "Priya Sharma",
    avatar: "PS",
    title: "Need teammate for Smart India Hackathon",
    description: "Looking for a backend developer who knows Node.js or Python. Our theme is healthcare IoT.",
    tags: ["Hackathon", "IoT", "Backend"],
    date: "2 hours ago",
    responses: 5,
  },
  {
    id: "2",
    author: "Rahul Verma",
    avatar: "RV",
    title: "Mini project partner - ML based attendance",
    description: "Building a face recognition attendance system. Need someone good with OpenCV and Python.",
    tags: ["Mini Project", "ML", "OpenCV"],
    date: "5 hours ago",
    responses: 3,
  },
  {
    id: "3",
    author: "Ananya Reddy",
    avatar: "AR",
    title: "Study group for Gate 2027 prep",
    description: "Forming a study group for GATE ECE. We meet every Saturday at the library.",
    tags: ["GATE", "Study Group", "ECE"],
    date: "1 day ago",
    responses: 12,
  },
  {
    id: "4",
    author: "Karthik M",
    avatar: "KM",
    title: "Web dev workshop volunteers needed",
    description: "Organizing a 2-day React + Tailwind workshop for juniors. Need 3 volunteers to help conduct sessions.",
    tags: ["Workshop", "React", "Volunteering"],
    date: "1 day ago",
    responses: 8,
  },
];

export const todaySchedule: DaySchedule[] = [
  { time: "09:00", subject: "Digital Signal Processing", type: "class" },
  { time: "10:00", subject: "Microprocessors Lab", type: "lab" },
  { time: "11:00", subject: "Microprocessors Lab", type: "lab" },
  { time: "12:00", subject: "Lunch Break", type: "free" },
  { time: "13:00", subject: "Signals & Systems", type: "class" },
  { time: "14:00", subject: "Free Hour", type: "free" },
  { time: "15:00", subject: "Electromagnetic Theory", type: "class" },
  { time: "16:00", subject: "Data Structures", type: "class" },
];

export const stressLevel = 3;

export const navItems = [
  { label: "Dashboard", path: "/", icon: LayoutDashboard },
  { label: "Skills & Projects", path: "/skills", icon: Brain },
  { label: "Recommendations", path: "/recommendations", icon: BookOpen },
  { label: "Collaboration", path: "/collaboration", icon: Users },
  { label: "Profile", path: "/profile", icon: User },
];
