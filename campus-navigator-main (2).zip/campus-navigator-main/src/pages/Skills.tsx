import { motion } from "framer-motion";
import { skills, projects, certifications } from "@/data/mockData";
import { Code2, Palette, Award, ExternalLink, FolderGit2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const levelColors = {
  beginner: "bg-info/10 text-info border-info/20",
  intermediate: "bg-warning/10 text-warning border-warning/20",
  advanced: "bg-success/10 text-success border-success/20",
};

const levelWidth = { beginner: "33%", intermediate: "66%", advanced: "100%" };

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.05 } },
};

const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0 },
};

const SkillBar = ({ skill, index }: { skill: typeof skills[0]; index: number }) => (
  <motion.div variants={item} className="group">
    <div className="flex items-center justify-between mb-1.5">
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-foreground">{skill.name}</span>
        <Badge variant="outline" className={`text-[10px] px-1.5 py-0 h-5 ${levelColors[skill.level]}`}>
          {skill.level}
        </Badge>
      </div>
      <span className="text-xs font-mono text-muted-foreground">{skill.progress}%</span>
    </div>
    <div className="h-2.5 bg-muted rounded-full overflow-hidden">
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: `${skill.progress}%` }}
        transition={{ duration: 0.8, ease: "easeOut", delay: index * 0.08 }}
        className={`h-full rounded-full ${
          skill.level === "advanced" ? "bg-gradient-to-r from-success/80 to-success" :
          skill.level === "intermediate" ? "bg-gradient-to-r from-warning/80 to-warning" :
          "bg-gradient-to-r from-info/80 to-info"
        }`}
      />
    </div>
  </motion.div>
);

const Skills = () => {
  const techSkills = skills.filter((s) => s.category === "technical");
  const softSkills = skills.filter((s) => s.category === "non-technical");

  return (
    <div className="page-container relative overflow-hidden">
      <div className="floating-gradient w-80 h-80 bg-primary -top-40 -right-40" />

      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="page-title">Skills & Projects</h1>
        <p className="page-subtitle">Track your growth, projects, and certifications.</p>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-6">
        <motion.div variants={container} initial="hidden" animate="show" className="glass-card rounded-xl p-5">
          <div className="section-header">
            <div className="section-icon bg-primary/10 text-primary"><Code2 className="w-4 h-4" /></div>
            <h3>Technical Skills</h3>
            <span className="ml-auto text-xs text-muted-foreground">{techSkills.length} skills</span>
          </div>
          <div className="space-y-4">
            {techSkills.map((skill, i) => <SkillBar key={skill.id} skill={skill} index={i} />)}
          </div>
        </motion.div>

        <motion.div variants={container} initial="hidden" animate="show" className="glass-card rounded-xl p-5">
          <div className="section-header">
            <div className="section-icon bg-accent/10 text-accent"><Palette className="w-4 h-4" /></div>
            <h3>Soft Skills</h3>
            <span className="ml-auto text-xs text-muted-foreground">{softSkills.length} skills</span>
          </div>
          <div className="space-y-4">
            {softSkills.map((skill, i) => <SkillBar key={skill.id} skill={skill} index={i} />)}
          </div>
        </motion.div>
      </div>

      {/* Projects */}
      <motion.div variants={container} initial="hidden" animate="show">
        <div className="section-header">
          <div className="section-icon bg-primary/10 text-primary"><FolderGit2 className="w-4 h-4" /></div>
          <h3 className="text-lg">Projects</h3>
          <span className="ml-auto text-xs text-muted-foreground">{projects.length} total</span>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map((project) => (
            <motion.div key={project.id} variants={item} className="glass-card rounded-xl p-5 flex flex-col group cursor-default">
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-semibold text-foreground text-sm group-hover:text-primary transition-colors">{project.title}</h4>
                <Badge variant={project.status === "completed" ? "default" : "secondary"} className="text-[10px] shrink-0">
                  {project.status === "completed" ? "✓ Done" : "⏳ In Progress"}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground flex-1 mb-3 leading-relaxed">{project.description}</p>
              <div className="flex flex-wrap gap-1.5">
                {project.skills.map((s) => (
                  <span key={s} className="text-[10px] px-2 py-0.5 rounded-full bg-primary/5 text-primary font-medium">{s}</span>
                ))}
              </div>
              <p className="text-[11px] text-muted-foreground mt-3 font-mono">{project.date}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Certifications */}
      <motion.div variants={container} initial="hidden" animate="show">
        <div className="section-header">
          <div className="section-icon bg-accent/10 text-accent"><Award className="w-4 h-4" /></div>
          <h3 className="text-lg">Certifications</h3>
        </div>
        <div className="space-y-2">
          {certifications.map((cert) => (
            <motion.div key={cert.id} variants={item} className="glass-card rounded-xl p-4 flex items-center justify-between group">
              <div>
                <p className="font-medium text-sm text-foreground group-hover:text-primary transition-colors">{cert.name}</p>
                <p className="text-xs text-muted-foreground">{cert.issuer} · {cert.date}</p>
              </div>
              <a href={cert.link} className="p-2 rounded-lg hover:bg-primary/10 transition-colors text-muted-foreground hover:text-primary">
                <ExternalLink className="w-4 h-4" />
              </a>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default Skills;
