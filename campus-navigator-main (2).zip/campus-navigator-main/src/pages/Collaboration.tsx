import { motion } from "framer-motion";
import { collabPosts } from "@/data/mockData";
import { MessageSquare, Users, Plus, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.06 } },
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
};

const Collaboration = () => {
  return (
    <div className="page-container relative overflow-hidden">
      <div className="floating-gradient w-80 h-80 bg-info -top-40 -right-40" />

      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-start justify-between">
        <div>
          <h1 className="page-title">Peer Collaboration</h1>
          <p className="page-subtitle">Find teammates, study groups, and project partners.</p>
        </div>
        <Button className="gap-2 shadow-lg shadow-primary/20">
          <Plus className="w-4 h-4" /> New Post
        </Button>
      </motion.div>

      {/* Quick stats */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="flex gap-4 overflow-x-auto pb-1"
      >
        {[
          { label: "Active Posts", value: collabPosts.length, icon: Zap },
          { label: "Total Responses", value: collabPosts.reduce((a, b) => a + b.responses, 0), icon: MessageSquare },
          { label: "Contributors", value: new Set(collabPosts.map(p => p.author)).size, icon: Users },
        ].map((stat) => (
          <div key={stat.label} className="glass-card rounded-xl px-4 py-3 flex items-center gap-3 min-w-fit">
            <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
              <stat.icon className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="text-lg font-bold text-foreground">{stat.value}</p>
              <p className="text-[11px] text-muted-foreground">{stat.label}</p>
            </div>
          </div>
        ))}
      </motion.div>

      <motion.div variants={container} initial="hidden" animate="show" className="space-y-4">
        {collabPosts.map((post) => (
          <motion.div
            key={post.id}
            variants={item}
            className="glass-card rounded-xl p-5 cursor-default"
          >
            <div className="flex items-start gap-4">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 text-primary text-sm font-bold shrink-0 ring-2 ring-primary/10">
                {post.avatar}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-foreground text-sm group-hover:text-primary transition-colors">{post.title}</h3>
                </div>
                <p className="text-sm text-muted-foreground mb-3 leading-relaxed">{post.description}</p>
                <div className="flex flex-wrap gap-1.5 mb-3">
                  {post.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-[10px] hover:bg-primary/10 hover:text-primary transition-colors cursor-default">{tag}</Badge>
                  ))}
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="font-medium text-foreground/70">{post.author}</span>
                  <span className="w-1 h-1 rounded-full bg-muted-foreground/30" />
                  <span>{post.date}</span>
                  <span className="w-1 h-1 rounded-full bg-muted-foreground/30" />
                  <span className="flex items-center gap-1 text-primary font-medium">
                    <MessageSquare className="w-3.5 h-3.5" /> {post.responses}
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
};

export default Collaboration;
