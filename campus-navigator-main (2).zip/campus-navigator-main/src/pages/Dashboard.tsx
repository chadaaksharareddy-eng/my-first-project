import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";
import { attendanceData, weeklyStudyHours, monthlyProgress, todaySchedule, stressLevel, studentProfile } from "@/data/mockData";
import { BookOpen, Clock, TrendingUp, Brain, Frown, Meh, Smile, Sparkles, ArrowUpRight } from "lucide-react";

const stressEmojis = [
  { icon: Smile, label: "Great", color: "text-success" },
  { icon: Smile, label: "Good", color: "text-success" },
  { icon: Meh, label: "Okay", color: "text-warning" },
  { icon: Meh, label: "Stressed", color: "text-accent" },
  { icon: Frown, label: "Overwhelmed", color: "text-destructive" },
];

const getGreeting = () => {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
};

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.06 },
  },
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
};

const StatCard = ({ icon: Icon, label, value, sub, color, trend }: { icon: any; label: string; value: string; sub?: string; color: string; trend?: string }) => (
  <motion.div variants={item} className="glass-card rounded-xl p-5 stat-glow group cursor-default">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">{label}</p>
        <div className="flex items-baseline gap-2 mt-1.5">
          <p className="text-2xl font-bold text-foreground">{value}</p>
          {trend && (
            <span className="flex items-center gap-0.5 text-xs font-medium text-success">
              <ArrowUpRight className="w-3 h-3" />{trend}
            </span>
          )}
        </div>
        {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
      </div>
      <div className={`p-2.5 rounded-xl transition-transform group-hover:scale-110 ${color}`}>
        <Icon className="w-5 h-5" />
      </div>
    </div>
  </motion.div>
);

const Dashboard = () => {
  const avgAttendance = Math.round(attendanceData.reduce((a, b) => a + b.percentage, 0) / attendanceData.length);
  const totalStudyHours = weeklyStudyHours.reduce((a, b) => a + b.hours, 0).toFixed(1);
  const currentGPA = monthlyProgress[monthlyProgress.length - 1].gpa;
  const totalSkills = monthlyProgress[monthlyProgress.length - 1].skills;

  return (
    <div className="page-container relative overflow-hidden">
      {/* Decorative gradient blobs */}
      <div className="floating-gradient w-96 h-96 bg-primary -top-48 -right-48" />
      <div className="floating-gradient w-72 h-72 bg-accent -bottom-36 -left-36" />

      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="relative">
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
          <Sparkles className="w-3.5 h-3.5 text-accent" />
          <span>Your daily overview</span>
        </div>
        <h1 className="page-title">
          {getGreeting()}, <span className="gradient-text">{studentProfile.name.split(" ")[0]}</span> 👋
        </h1>
        <p className="page-subtitle">Here's your academic & personal pulse for today.</p>
      </motion.div>

      {/* Stats Row */}
      <motion.div variants={container} initial="hidden" animate="show" className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={BookOpen} label="Avg Attendance" value={`${avgAttendance}%`} sub="Across 5 subjects" color="bg-primary/10 text-primary" />
        <StatCard icon={Clock} label="Study This Week" value={`${totalStudyHours}h`} trend="12%" color="bg-info/10 text-info" />
        <StatCard icon={TrendingUp} label="Current GPA" value={`${currentGPA}`} sub="Semester 4" color="bg-success/10 text-success" />
        <StatCard icon={Brain} label="Skills Tracked" value={`${totalSkills}`} sub="3 advanced level" color="bg-accent/10 text-accent" />
      </motion.div>

      {/* Charts Row */}
      <motion.div variants={container} initial="hidden" animate="show" className="grid lg:grid-cols-2 gap-6">
        {/* Attendance Chart */}
        <motion.div variants={item} className="glass-card rounded-xl p-5">
          <div className="section-header">
            <div className="section-icon bg-primary/10 text-primary"><BookOpen className="w-4 h-4" /></div>
            <h3>Subject Attendance</h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={attendanceData} layout="vertical" margin={{ left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis type="category" dataKey="subject" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} width={100} tickFormatter={(v) => v.length > 14 ? v.slice(0, 14) + "…" : v} />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12, fontSize: 13 }}
                  formatter={(value: number) => [`${value}%`, "Attendance"]}
                  cursor={{ fill: "hsl(var(--primary) / 0.05)" }}
                />
                <Bar dataKey="percentage" fill="hsl(var(--primary))" radius={[0, 8, 8, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Study Hours Chart */}
        <motion.div variants={item} className="glass-card rounded-xl p-5">
          <div className="section-header">
            <div className="section-icon bg-info/10 text-info"><Clock className="w-4 h-4" /></div>
            <h3>Weekly Study Hours</h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyStudyHours}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="day" tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12, fontSize: 13 }} cursor={{ fill: "hsl(var(--primary) / 0.05)" }} />
                <Bar dataKey="hours" fill="hsl(var(--chart-3))" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </motion.div>

      {/* Bottom Row */}
      <motion.div variants={container} initial="hidden" animate="show" className="grid lg:grid-cols-3 gap-6">
        {/* Today Schedule */}
        <motion.div variants={item} className="glass-card rounded-xl p-5 lg:col-span-1">
          <div className="section-header">
            <div className="section-icon bg-accent/10 text-accent"><Clock className="w-4 h-4" /></div>
            <h3>Today's Schedule</h3>
          </div>
          <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
            {todaySchedule.map((slot, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.04 }}
                className={`flex items-center gap-3 p-2.5 rounded-lg text-sm transition-colors hover:bg-muted/50 ${
                  slot.type === "class" ? "bg-primary/5" : slot.type === "lab" ? "bg-info/5" : "bg-muted/30"
                }`}
              >
                <span className="font-mono text-xs text-muted-foreground w-12 shrink-0">{slot.time}</span>
                <div className={`w-2 h-2 rounded-full shrink-0 ${
                  slot.type === "class" ? "bg-primary animate-pulse-soft" : slot.type === "lab" ? "bg-info" : "bg-muted-foreground/30"
                }`} />
                <span className="text-foreground truncate">{slot.subject}</span>
                <span className={`ml-auto text-[10px] uppercase tracking-wider font-medium px-1.5 py-0.5 rounded ${
                  slot.type === "class" ? "text-primary bg-primary/10" : slot.type === "lab" ? "text-info bg-info/10" : "text-muted-foreground"
                }`}>{slot.type}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* GPA Trend */}
        <motion.div variants={item} className="glass-card rounded-xl p-5">
          <div className="section-header">
            <div className="section-icon bg-success/10 text-success"><TrendingUp className="w-4 h-4" /></div>
            <h3>GPA & Skills Growth</h3>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlyProgress}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis yAxisId="left" domain={[6, 10]} tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12, fontSize: 13 }} />
                <Line yAxisId="left" type="monotone" dataKey="gpa" stroke="hsl(var(--primary))" strokeWidth={2.5} dot={{ fill: "hsl(var(--primary))", r: 4 }} activeDot={{ r: 6, strokeWidth: 2 }} />
                <Line yAxisId="right" type="monotone" dataKey="skills" stroke="hsl(var(--accent))" strokeWidth={2.5} dot={{ fill: "hsl(var(--accent))", r: 4 }} activeDot={{ r: 6, strokeWidth: 2 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Stress Level */}
        <motion.div variants={item} className="glass-card rounded-xl p-5">
          <div className="section-header">
            <div className="section-icon bg-destructive/10 text-destructive"><Smile className="w-4 h-4" /></div>
            <h3>Wellness Check</h3>
          </div>
          <div className="flex flex-col items-center justify-center h-56 gap-4">
            {(() => {
              const emoji = stressEmojis[stressLevel - 1];
              const EmojiIcon = emoji.icon;
              return (
                <>
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 200, delay: 0.3 }}
                  >
                    <EmojiIcon className={`w-16 h-16 ${emoji.color}`} />
                  </motion.div>
                  <p className="text-lg font-semibold text-foreground">{emoji.label}</p>
                </>
              );
            })()}
            <div className="w-full flex items-center gap-2 px-2">
              <span className="text-xs text-muted-foreground">😊</span>
              <div className="flex-1 h-2.5 bg-muted rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(stressLevel / 5) * 100}%` }}
                  transition={{ duration: 0.8, ease: "easeOut", delay: 0.4 }}
                  className="h-full rounded-full bg-gradient-to-r from-success via-warning to-destructive"
                />
              </div>
              <span className="text-xs text-muted-foreground">😰</span>
            </div>
            <p className="text-xs text-muted-foreground text-center">Stress Level: {stressLevel}/5</p>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Dashboard;
