import { motion } from "framer-motion";
import { studentProfile, skills, projects, certifications } from "@/data/mockData";
import { Mail, Calendar, Download, Share2, ExternalLink, Code2, Award, FolderGit2, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const levelColors = {
  beginner: "bg-info/10 text-info",
  intermediate: "bg-warning/10 text-warning",
  advanced: "bg-success/10 text-success",
};

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.06 } },
};

const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0 },
};

const Profile = () => {
  return (
    <div className="p-4 lg:p-8 max-w-4xl mx-auto space-y-6 relative overflow-hidden">
      <div className="floating-gradient w-96 h-96 bg-primary -top-48 -right-48" />
      <div className="floating-gradient w-64 h-64 bg-accent -bottom-32 -left-32" />

      {/* Header Card */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card rounded-2xl p-6 lg:p-8 relative overflow-hidden">
        {/* Decorative header gradient */}
        <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-br from-primary/10 to-accent/5 -z-0" />
        <div className="relative flex flex-col sm:flex-row items-center sm:items-start gap-6">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
            className="flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-primary/70 text-primary-foreground text-2xl font-bold shadow-lg shadow-primary/20 ring-4 ring-card"
          >
            {studentProfile.avatar}
          </motion.div>
          <div className="text-center sm:text-left flex-1">
            <h1 className="text-2xl font-bold text-foreground">{studentProfile.name}</h1>
            <p className="text-muted-foreground text-sm mt-1">{studentProfile.department} · Semester {studentProfile.semester}</p>
            <p className="text-sm text-muted-foreground mt-2 max-w-lg leading-relaxed">{studentProfile.bio}</p>
            <div className="flex flex-wrap items-center gap-3 mt-3 justify-center sm:justify-start text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5" />{studentProfile.email}</span>
              <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />Joined {studentProfile.joinedDate}</span>
            </div>
          </div>
          <div className="flex gap-2 shrink-0">
            <Button variant="outline" size="sm" className="gap-1.5 hover:border-primary/30 hover:text-primary"><Share2 className="w-3.5 h-3.5" /> Share</Button>
            <Button size="sm" className="gap-1.5 shadow-lg shadow-primary/20"><Download className="w-3.5 h-3.5" /> Resume</Button>
          </div>
        </div>
      </motion.div>

      {/* Skills */}
      <motion.div variants={container} initial="hidden" animate="show" className="glass-card rounded-2xl p-6">
        <div className="section-header">
          <div className="section-icon bg-primary/10 text-primary"><Code2 className="w-4 h-4" /></div>
          <h2>Skills</h2>
          <span className="ml-auto text-xs text-muted-foreground">{skills.length} tracked</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {skills.map((skill) => (
            <motion.div key={skill.id} variants={item} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-muted hover:bg-primary/5 transition-colors cursor-default">
              <span className="text-sm font-medium text-foreground">{skill.name}</span>
              <Badge variant="outline" className={`text-[10px] px-1.5 py-0 h-5 border-0 ${levelColors[skill.level]}`}>
                {skill.level}
              </Badge>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Projects */}
      <motion.div variants={container} initial="hidden" animate="show" className="glass-card rounded-2xl p-6">
        <div className="section-header">
          <div className="section-icon bg-primary/10 text-primary"><FolderGit2 className="w-4 h-4" /></div>
          <h2>Projects</h2>
        </div>
        <div className="space-y-4">
          {projects.map((project) => (
            <motion.div key={project.id} variants={item} className="border-b border-border/50 last:border-0 pb-4 last:pb-0 hover:bg-muted/30 -mx-2 px-2 py-2 rounded-lg transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-medium text-sm text-foreground">{project.title}</h3>
                  <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{project.description}</p>
                </div>
                <Badge variant={project.status === "completed" ? "default" : "secondary"} className="text-[10px] shrink-0 ml-2">
                  {project.status === "completed" ? "✓ Done" : "⏳ In Progress"}
                </Badge>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {project.skills.map((s) => (
                  <span key={s} className="text-[10px] px-2 py-0.5 rounded-full bg-primary/5 text-primary font-medium">{s}</span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Certifications */}
      <motion.div variants={container} initial="hidden" animate="show" className="glass-card rounded-2xl p-6">
        <div className="section-header">
          <div className="section-icon bg-accent/10 text-accent"><Award className="w-4 h-4" /></div>
          <h2>Certifications</h2>
        </div>
        <div className="space-y-3">
          {certifications.map((cert) => (
            <motion.div key={cert.id} variants={item} className="flex items-center justify-between hover:bg-muted/30 -mx-2 px-2 py-2 rounded-lg transition-colors">
              <div>
                <p className="font-medium text-sm text-foreground">{cert.name}</p>
                <p className="text-xs text-muted-foreground">{cert.issuer} · {cert.date}</p>
              </div>
              <a href={cert.link} className="p-2 rounded-lg hover:bg-primary/10 transition-colors text-muted-foreground hover:text-primary">
                <ExternalLink className="w-4 h-4" />
              </a>
            </motion.div>
          ))}
        </div>
      </motion.div>

      <p className="text-center text-xs text-muted-foreground pb-4">
        campuspulse.in/{studentProfile.name.toLowerCase().replace(" ", "")} · Generated by CampusPulse
      </p>
    </div>
  );
};

export default Profile;
