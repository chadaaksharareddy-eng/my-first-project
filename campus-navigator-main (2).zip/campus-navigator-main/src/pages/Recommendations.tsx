import { motion } from "framer-motion";
import { attendanceData, skills, stressLevel } from "@/data/mockData";
import { AlertTriangle, TrendingUp, Brain, Heart, Lightbulb, BookOpen, Target, Sparkles } from "lucide-react";

interface Recommendation {
  id: string;
  icon: any;
  title: string;
  description: string;
  type: "warning" | "suggestion" | "wellness" | "achievement";
  priority: "high" | "medium" | "low";
}

const generateRecommendations = (): Recommendation[] => {
  const recs: Recommendation[] = [];

  attendanceData.forEach((sub) => {
    if (sub.percentage < 75) {
      recs.push({
        id: `att-${sub.subject}`,
        icon: AlertTriangle,
        title: `Low Attendance: ${sub.subject}`,
        description: `Your attendance is at ${sub.percentage}%. You need ${Math.ceil((0.75 * sub.total - sub.attended))} more classes to reach 75%. Consider prioritizing this subject.`,
        type: "warning",
        priority: "high",
      });
    }
  });

  if (skills.length < 5) {
    recs.push({
      id: "skills-low",
      icon: Brain,
      title: "Expand Your Skill Set",
      description: "You have fewer than 5 tracked skills. Consider learning trending technologies like Docker, TypeScript, or Cloud Computing to boost your placement profile.",
      type: "suggestion",
      priority: "medium",
    });
  }

  if (stressLevel >= 4) {
    recs.push({
      id: "stress-high",
      icon: Heart,
      title: "Take Care of Yourself",
      description: "Your stress level is high. Consider visiting the campus counseling center, taking short breaks between study sessions, or joining a recreational club.",
      type: "wellness",
      priority: "high",
    });
  }

  recs.push(
    {
      id: "trending-skills",
      icon: TrendingUp,
      title: "Trending: Learn Cloud & DevOps",
      description: "Cloud computing and DevOps skills are in high demand for 2026 placements. AWS, Docker, and Kubernetes are the top picks. Start with AWS Cloud Practitioner certification.",
      type: "suggestion",
      priority: "medium",
    },
    {
      id: "project-tip",
      icon: Target,
      title: "Add a Capstone Project",
      description: "Having a strong capstone project significantly improves placement chances. Consider building something that combines IoT with web technologies — your strongest skills.",
      type: "suggestion",
      priority: "low",
    },
    {
      id: "study-tip",
      icon: BookOpen,
      title: "Optimize Study Sessions",
      description: "Research shows 25-minute focused sessions (Pomodoro) with 5-minute breaks improve retention by 30%. Try this technique during your free hours.",
      type: "suggestion",
      priority: "low",
    }
  );

  return recs;
};

const typeStyles = {
  warning: "border-l-destructive bg-destructive/5",
  suggestion: "border-l-primary bg-primary/5",
  wellness: "border-l-success bg-success/5",
  achievement: "border-l-accent bg-accent/5",
};

const iconStyles = {
  warning: "text-destructive bg-destructive/10",
  suggestion: "text-primary bg-primary/10",
  wellness: "text-success bg-success/10",
  achievement: "text-accent bg-accent/10",
};

const priorityBadge = {
  high: "bg-destructive/10 text-destructive",
  medium: "bg-warning/10 text-warning",
  low: "bg-muted text-muted-foreground",
};

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.06 } },
};

const cardItem = {
  hidden: { opacity: 0, x: -20, scale: 0.98 },
  show: { opacity: 1, x: 0, scale: 1 },
};

const Recommendations = () => {
  const recs = generateRecommendations();
  const highPriority = recs.filter(r => r.priority === "high").length;

  return (
    <div className="page-container relative overflow-hidden">
      <div className="floating-gradient w-72 h-72 bg-accent -top-36 -left-36" />

      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="page-title">Smart Recommendations</h1>
        <p className="page-subtitle">Personalized suggestions based on your academic data and activity.</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="flex items-center gap-3 p-4 rounded-xl bg-gradient-to-r from-primary/5 to-accent/5 border border-primary/10"
      >
        <div className="p-2 rounded-lg bg-primary/10">
          <Sparkles className="w-4 h-4 text-primary" />
        </div>
        <div>
          <p className="text-sm font-medium text-foreground">
            {highPriority > 0 ? `${highPriority} action${highPriority > 1 ? 's' : ''} need your attention` : 'All looking good!'}
          </p>
          <p className="text-xs text-muted-foreground">Auto-generated from your attendance, skills, and wellness data.</p>
        </div>
      </motion.div>

      <motion.div variants={container} initial="hidden" animate="show" className="space-y-3">
        {recs.map((rec) => (
          <motion.div
            key={rec.id}
            variants={cardItem}
            className={`glass-card rounded-xl p-5 border-l-4 ${typeStyles[rec.type]} cursor-default`}
          >
            <div className="flex items-start gap-4">
              <div className={`p-2.5 rounded-xl shrink-0 ${iconStyles[rec.type]}`}>
                <rec.icon className="w-5 h-5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-sm text-foreground">{rec.title}</h3>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${priorityBadge[rec.priority]}`}>
                    {rec.priority}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">{rec.description}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
};

export default Recommendations;
